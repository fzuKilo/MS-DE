
###
This package is a MATLAB source code of MS-DE.

###
System configurations in our experimental environment:

OS: Windows 7
CPU: core i5 (3.4GHz)
RAM: 8GB
Language: Matlab

###
How to execute:

Step 1. Extract MS_DE.zip file

Step 2. Open MS_DE_main.m

Step 3. Set the problem size (line 10) and number of runs (line 15) at MS_DE_main.m

Step 4. Execute MS_DE_main.m, the final result will be saved in the txt file


###
For any queries please feel free to contact me (187064463@qq.com).

###
Please use MATLAB R2016a or later versions to run the algorithm.

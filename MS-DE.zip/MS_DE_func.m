% Description    This function is used to run the Multi-strategy
%                Differential Evolution (MS-DE) algorithm on the 
%                CEC 2017 test Suite
%% Some parts of this code refer to JADE (Zhang et al.), CIPDE (Zheng et al.),LSHADE (Tanabe et al), 
%% IMODE (Sallam et al.), MadDE (Biswas et al.), Di-DE (Meng et al.) 
%
function [ bsf_solution,bsf_fit_var,nfes,RecordT] = MS_DE_func(fhd, D, Max_nfe, VRmin, VRmax, varargin )

    % random seeds
    stm = RandStream('swb2712','Seed',sum(100*clock));
    RandStream.setGlobalStream(stm);
    %argument passing
    

    fidvec = cell2mat(varargin);
    fid = fidvec(1);
    runid = fidvec(2); 
    % global best
    targetbest = [100;200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400;
    1500;1600;1700;1800;1900;2000;2100;2200;2300;2400;2500;2600;2700;2800;2900;3000];

    name = ['MS_DE_fid_',num2str(fid),'_',num2str(D),'D_',num2str(runid),'.dat'];
    fout = fopen(name,'a');
    problem_size=D;
    max_nfes=Max_nfe; %maximum number of function evaluations

    lu = [VRmin * ones(1, problem_size); VRmax * ones(1, problem_size)];% lower and upper bounds    

    arc_rateA = 1;
    arc_rateB = 2;
    memory_size = 5; % denotes the H of the paper

    max_pop_size =round( 25 * log(problem_size)*sqrt(problem_size));  %The maximum value of  population size 
    min_pop_size = 4.0;%The minimum value of population size
    pop_size = max_pop_size;%population size
 
    nfep = 0.2; % denotes the st of paper  

    pmax=0.2;%The maximum value of parameter p
    pmin=0.1;%The minimum value of parameter p

    T = 90; % T stands for the user-defined threshold of stagnation
    UN_UP = zeros(pop_size,1);% number of the consecutive unsuccessful update
    
    num_de = 2;                              %% number of DE operators
    count_S = zeros(1, num_de);              %% Number of individuals successfully updated
    probDE=1./num_de .* ones(1, num_de);     %% operator probability  
    
    prob_ls =0.1; % a probability for local search

    tic;
    
   %% Initialize the main population
    popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
    pop = popold; % the old population becomes the current population

    fitness = feval(fhd,pop',varargin{:}); % Calculate the fitness value of the population
    fitness = fitness';
    nfes = 0; %current number of function evaluations
    bsf_fit_var = 1e+30; %The best fitness value
    bsf_solution = zeros(1, problem_size);%The solution corresponding to the best fitness value
    
    for i = 1 : pop_size
        nfes = nfes + 1;

        if fitness(i) < bsf_fit_var
            bsf_fit_var = fitness(i);
            bsf_solution = pop(i, :);
        end

        if nfes > max_nfes; break; end
    end
   
    
    fprintf(fout,'%d\t%.15f\n',nfes,bsf_fit_var-targetbest(fid));
    
   
    
    CRm = 0.5; % Initial value of muCR
    Fm = 0.5; % Initial value of muF
    
    memory_sf = Fm .* ones(memory_size, 1);
    memory_cr = CRm .* ones(memory_size, 1);
    memory_pos = 1; %position of historical memory

    archiveA.NP = round( arc_rateA * pop_size); % the maximum size of the inferior archive
    archiveA.pop = zeros(0, problem_size); % the solutions stored in the inferior archive
    archiveA.funvalues = zeros(0, 1); % the function value of the inferior archived solutions
    
    archiveB.NP = round(arc_rateB * pop_size); % the maximum size of the historical archive
    archiveB.pop = zeros(0, problem_size); % the solutions stored in the historical archive
    archiveB.funvalues = zeros(0, 1); % the function value of the historical archived solutions
    

    
    iter=1;
    %% main loop
    while nfes < max_nfes
        iter=iter+1;
        p_best_rate = pmax-(pmax-pmin)*(nfes/max_nfes); % Eq.(21)
        pop = popold; % the old population becomes the current population
        [temp_fit, sorted_index] = sort(fitness, 'ascend');

        mem_rand_index = ceil(memory_size * rand(pop_size, 1));%The index is a random integer that is selected from [1, H].
        mu_sf = memory_sf(mem_rand_index);
        mu_cr = memory_cr(mem_rand_index);

        %% for generating crossover rate
        cr = normrnd(mu_cr, 0.1);
        term_pos = find(mu_cr == -1);
        cr(term_pos) = 0;
        cr = min(cr, 1);
        cr = max(cr, 0);

        %% for generating scaling factor
        sf = mu_sf + 0.1 * tan(pi * (rand(pop_size, 1) - 0.5));
        pos = find(sf <= 0);

        while ~ isempty(pos)
            sf(pos) = mu_sf(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
            pos = find(sf <= 0);
        end

        sf = min(sf, 1); 

        r0 = [1 : pop_size];
        popAllA = [pop; archiveA.pop];
        popAllB = [pop; archiveB.pop];
        [r1, r2, r3] = gnR1R2R3(pop_size, size(popAllA, 1),size(popAllB, 1), r0);
      
        pNP = max(round(p_best_rate * pop_size), 2); %% choose at least two best solutions
        randindex = ceil(rand(1, pop_size) .* pNP); %% select from [1, 2, 3, ..., pNP]
        randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
        pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions


        %% ========= Mutation Operation ===========================
        bb = rand(pop_size, 1);
        probiter = probDE(1,:);

        de_1 = bb <= probiter(1)*ones(pop_size, 1);
        de_2 = bb > probiter(1)*ones(pop_size, 1) &  bb <= (ones(pop_size, 1));

        vi = zeros(pop_size, problem_size);
   
        %% DE/current-to-p-best/1 with inferior archive
        vi(de_1==1, :)  = pop(de_1==1, :) + ...
              sf(de_1==1, ones(1, problem_size)) .* ...
              (pbest(de_1==1, :) - pop(de_1==1, :) + pop(r1(de_1==1), :) - popAllA(r2(de_1==1), :));

        %% DE/current-to-p-best/1 with historical archive
        vi(de_2==1, :)  = pop(de_2==1, :) + ...
              sf(de_2==1, ones(1, problem_size)) .* ...
              (pbest(de_2==1, :) - pop(de_2==1, :) + pop(r1(de_2==1), :) - popAllB(r3(de_2==1), :));
    
        %vi = pop + sf(:, ones(1, problem_size)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
        %vi = boundConstraint(vi, pop, lu);

        mask = rand(pop_size, problem_size) > cr(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
        rows = (1 : pop_size)'; 
        cols = floor(rand(pop_size, 1) * problem_size)+1; % choose one position where the element of ui doesn't come from the parent
        jrand = sub2ind([pop_size problem_size], rows, cols); mask(jrand) = false;
        ui = vi;

        popX = pop; 
        popX(UN_UP > T,:) = pbest(UN_UP > T,:) ;%%crossover operation when the target vector traps into stagnation --- Equation (24)
        UN_UP(UN_UP > T) = 0;%
        ui(mask) = popX(mask); 
        ui = boundConstraint(ui, pop, lu); 

        children_fitness = feval(fhd, ui', varargin{:});
        children_fitness = children_fitness';
       
        for i = 1 : pop_size
            nfes = nfes + 1;

            if children_fitness(i) < bsf_fit_var
                bsf_fit_var = children_fitness(i);
                bsf_solution = ui(i, :);
            end

            %%	if nfes > max_nfes; exit(1); end
            if nfes > max_nfes; break; end
        end       

%       dif = abs(fitness - children_fitness);
       %% The Euclidean distance between the trial and target vectors
         
        dif= zeros(pop_size,1);
        for i = 1 : pop_size
            dif(i)=pdist2(pop(i,:),ui(i,:),'euclidean');
        end


              
       %% ========= update Prob. of each DE operator====================
        diff2 = max(0,(fitness - children_fitness))./abs(fitness);
        count_S(1)=max(0,mean(diff2(de_1==1)));
        count_S(2)=max(0,mean(diff2(de_2==1)));
   
        if count_S~=0
            probDE = max(0.1,min(0.9,count_S./(sum(count_S))));
        else
            probDE = 1.0/2 * ones(1,2);
        end
        % probDE
        
        
        % I == 1: the parent is better; I == 2: the offspring is better       
        [fitness, I] = min([fitness, children_fitness], [], 2);
        
        %      isempty(popold(I == 1, :))   
        archiveA = updateArchive(archiveA, popold(I == 2, :), fitness(I == 2));
        archiveB = updateArchive(archiveB, popold, fitness);

        popold = pop;
        popold(I == 2, :) = ui(I == 2, :);

        % update the CCU Eq.(23)
        UN_UP(I == 1) = UN_UP(I == 1) + 1;
        UN_UP(I == 2) = 0;
        
        
        goodCR = cr(I == 2);  
        goodF = sf(I == 2);
        dif_val = dif(I == 2);
        
 
        num_success_params = numel(goodCR);

        if num_success_params > 0 
            sum_dif = sum(dif_val);
            dif_val = dif_val / sum_dif;

            %% for updating the memory of scaling factor 
            memory_sf(memory_pos) = (dif_val' * (goodF .^ 2)) / (dif_val' * goodF);

            %% for updating the memory of crossover rate
            if max(goodCR) == 0 || memory_cr(memory_pos)  == -1
               memory_cr(memory_pos)  = -1;
            else
               memory_cr(memory_pos) = (dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR);
            end

            memory_pos = memory_pos + 1;
            if memory_pos > memory_size;  memory_pos = 1; end       
        end

       %% for resizing the population size
        %%{
       
        if nfes<= nfep*max_nfes
             plan_pop_size=pop_size;% fixed population size
        else
             plan_pop_size = round((((min_pop_size - max_pop_size) / (max_nfes-nfep*max_nfes)) * (nfes-nfep*max_nfes)) + max_pop_size);
             %the population size is adjusted in a liner reduction manner 
        end
        %}
        %%
        if pop_size > plan_pop_size
            reduction_ind_num = pop_size - plan_pop_size;
            if pop_size - reduction_ind_num <  min_pop_size
                reduction_ind_num = pop_size - min_pop_size;
            end

            pop_size = pop_size - reduction_ind_num;
            for r = 1 : reduction_ind_num
                [valBest indBest] = sort(fitness, 'ascend');
                worst_ind = indBest(end);
                popold(worst_ind,:) = [];
                pop(worst_ind,:) = [];
                fitness(worst_ind,:) = [];
                UN_UP(worst_ind,:) = [];
            end

            archiveA.NP = round(arc_rateA * pop_size); 
            if size(archiveA.pop, 1) > archiveA.NP 
                rndpos = randperm(size(archiveA.pop, 1));
                rndpos = rndpos(1 : archiveA.NP);
                archiveA.pop = archiveA.pop(rndpos, :);
            end
            
            archiveB.NP = round(arc_rateB * pop_size); 
            if size(archiveB.pop, 1) > archiveB.NP 
                rndpos = randperm(size(archiveB.pop, 1));
                rndpos = rndpos(1 : archiveB.NP);
                archiveB.pop = archiveB.pop(rndpos, :);
            end
            
        end
        
        %%{
        %%============================local search ====================================
        if nfes>0.9*max_nfes && nfes<max_nfes 
            if rand<prob_ls
                Par.LS_FE =0;
                [bestx,bestold,nfes,succ] = LS2 (bsf_solution,bsf_fit_var,Par,nfes,fid,max_nfes,lu(1, :),lu(2, :));
                %function [x,f,current_eval,succ] = LS2 (bestx,f,Par,current_eval,I_fno,Max_FES,xmin,xmax)
                if succ==1 %% if LS2 was successful
                    bsf_solution = bestx;
                    bsf_fit_var = bestold;
                    [~,worst_ind]=max(fitness);
                    popold(worst_ind,:) = bsf_solution;
                    pop(worst_ind,:) = bsf_solution;
                    fitness(worst_ind,:) = bsf_fit_var;
                    prob_ls=0.15;
                else
                    prob_ls=0.001; %% set prob_ls to a small value if LS was not successful
                end
            end
        end
        %}
        if mod(iter,5*D)==0
            fprintf(fout,'%d\t%.15f\n',nfes,bsf_fit_var-targetbest(fid));
        end
      
    end

    

    fprintf(fout,'%d\t%.15f\n',nfes,bsf_fit_var-targetbest(fid));
    RecordT = toc;
    fclose(fout);
end
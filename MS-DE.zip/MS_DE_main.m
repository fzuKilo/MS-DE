%% ============ Multi-strategy Differential evolution (MS-DE)  ============
% For any queries please feel free to contact 187064463@qq.com

% clear all
% mex cec17_func.cpp -DWINDOWS
clear;
clc;
format long;
fun_nums=30;
D=30; % problem size
Xmin=-100;
Xmax=100;
ps = 100;
nfe_max=10000*D;
runs=2 ;%51;% number of runs
%xbest ����λ�þ���
xbest(runs,D) = inf;
xbest(:) = inf;
%fbest ����ֵ����
fbest(fun_nums,runs) = inf;
fbest(:) = inf;
%error ����
f_error(fun_nums,runs) = inf;
f_error(:) = inf;
%f_mean ��ֵ����
f_mean(fun_nums) = inf;
f_mean(:) = inf;
%f_median ��ֵ����
f_median(fun_nums) = inf;
f_median(:) = inf;
%f_std ��׼��
f_std(fun_nums) = inf;
f_std(:) = inf;
Time = zeros(fun_nums,runs);
best_mean_std = zeros(fun_nums,5);%�洢����ֵ ����ID������ֵ��ƽ��ֵ����׼��,��ֵλ��
targetbest = [100;200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400;
    1500;1600;1700;1800;1900;2000;2100;2200;2300;2400;2500;2600;2700;2800;2900;3000];

fhd=str2func('cec17_func');
fname = ['MS_DE_',num2str(D),'D.txt'];
f_out = fopen(fname,'wt');
fname_b_m_e_std = ['MS_DE_b_m_e_std_',num2str(D),'D.txt'];
f_out_b_m_e_std = fopen(fname_b_m_e_std,'wt');
ftime = ['MS_DE_Time_',num2str(D),'D.txt'];
f_tout = fopen(ftime,'a');

for i=1:fun_nums %5 
    fun_num=i;
    disp(['fid:',num2str(fun_num)]);
    fprintf(f_out,'fid:%d\n',fun_num);
    for j=1:runs
        [gbest,gbestval,FES,RecordT]= MS_DE_func(fhd,D,nfe_max,Xmin,Xmax,fun_num,j);
        xbest(j,:)=gbest;   %Dά������
        fbest(i,j)=gbestval;%��һ��ֵ
        disp(['x[',num2str(gbest),']=',num2str(gbestval-targetbest(i),15)]);
        fprintf(f_out,'x[%s]=%s\n',num2str(gbest),num2str(gbestval-targetbest(i)));
        Time(i,j) = RecordT;
    end
    [bestval,best] = min(fbest(i,:));
    loc = xbest(best,:);
    disp(['Best[',num2str(loc),']=',num2str(bestval-targetbest(i),15)]);
    fprintf(f_out,'Best[%s]=%s\n',num2str(loc),num2str(bestval-targetbest(i)));
    %f_mean(i)=mean(fbest(i,:));
    %disp(['mean[ ',num2str(i),']=',num2str(f_mean(i)-targetbest(i),15)]);
    f_error(i,:) = fbest(i,:) - targetbest(i);
    f_mean(i)=mean(f_error(i,:));
    f_median(i) = median(f_error(i,:));
    f_std(i) = std(f_error(i,:));
    disp(['mean[',num2str(i),']=',num2str(f_mean(i),15)]);
    fprintf(f_out,'mean[%s]=%s\n',num2str(i),num2str(f_mean(i)));
    disp(['median[',num2str(i),']=',num2str(f_median(i),15)]);
    fprintf(f_out,'median[%s]=%s\n',num2str(i),num2str(f_median(i)));
    disp(['std[',num2str(i),']=',num2str(f_std(i),15)]);
    fprintf(f_out,'std[%s]=%s\n',num2str(i),num2str(f_std(i)));
    
    best_mean_std(i,1)=i; %
    best_mean_std(i,2)=bestval-targetbest(i);
    best_mean_std(i,3)=f_mean(i);
    best_mean_std(i,4)=f_std(i);
    best_mean_std(i,5)=best;
    fprintf(f_out_b_m_e_std,'%s\n',num2str(best_mean_std(i,:)));
    
    %%{
    for j = 1: runs
        %disp(['T2=',num2str(Time(i,j),15)]);
        fprintf(f_tout,'T2=\t%.15f\n',Time(i,j));
    end
    MeanT=mean(Time(i,:));
    %disp(['meanT[',num2str(i),']=',num2str(MeanT,15)]);
    fprintf(f_tout,'MeanT2=\t%.15f\n',MeanT);
    %}
end
fclose(f_out);
fclose(f_out_b_m_e_std);
fclose(f_tout);
clear all;